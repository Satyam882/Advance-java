package com.app.pojos;

public enum CardType {
CREDIT_CARD,DEBIT_CARD,FOREX
}
